[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/XK3q6Hkl)
# JavaScript Fundamentals Exercise

Welcome! The goal of this exercise is to practice writing basic JavaScript functions.

## Your Task

Your task is to implement a series of functions in the index.js file. Each function is described with comments explaining what it should do, what parameters it takes, and what it should return.

Do not change the function names or the module.exports line at the bottom of the file.
